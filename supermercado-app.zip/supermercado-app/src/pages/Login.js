import React, { useState } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        try {
            // Enviando solicitação de login
            const response = await axios.post('http://localhost:8081/users/login', {
                nome: username,
                senha: password,
            });

            // Verificando se os dados de login estão presentes
            if (response.data && response.data.id && response.data.nome) {
                const { id, nome } = response.data;

                // Salvando ID, nome e senha no localStorage
                localStorage.setItem('user', JSON.stringify({ id, nome, senha: password }));

                // Redireciona para a página de produtos
                navigate('/produtos');
            } else {
                setError('Erro ao tentar fazer login. Por favor, tente novamente.');
            }
        } catch (err) {
            if (err.response && err.response.status === 401) {
                setError('ID ou senha incorretos. Tente novamente.');
            } else {
                setError('Erro ao tentar fazer login. Por favor, tente novamente mais tarde.');
            }
        }
    };

    return (
        <div className="login-page">
            <Container>
                <Row className="justify-content-md-center">
                    <Col md={4}>
                        <div className="login-form">
                            <div className="text-center mb-4">
                                <img
                                    src="/logo.png"
                                    alt="Logo do Supermercado SPB"
                                    className="mb-4"
                                />
                                <h4>Supermercado SPB</h4>
                                <p>Assessment do PB: Engenharia de Softwares Escaláveis</p>
                            </div>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="formUsername" className="mb-3">
                                    <Form.Label>Nome:</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Digite seu nome"
                                        value={username}
                                        onChange={(e) => setUsername(e.target.value)}
                                        required
                                    />
                                </Form.Group>

                                <Form.Group controlId="formPassword" className="mb-3">
                                    <Form.Label>Senha:</Form.Label>
                                    <Form.Control
                                        type="password"
                                        placeholder="Digite sua senha"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        required
                                    />
                                </Form.Group>

                                {error && <p style={{ color: 'red' }}>{error}</p>}

                                <Button variant="primary" type="submit" className="w-100">
                                    Acessar sistema
                                </Button>

                                <div className="text-center mt-3">
                                    <p>
                                        Não possui conta? {' '}
                                        <a href="novo_usuario" className="text-decoration-none">
                                            Crie uma nova conta
                                        </a>
                                    </p>
                                </div>
                            </Form>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default Login;
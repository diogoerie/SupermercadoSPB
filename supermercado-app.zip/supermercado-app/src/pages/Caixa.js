import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Table, Navbar, Nav } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Caixa = () => {
    const [transacoes, setTransacoes] = useState([]);
    const [mensagem, setMensagem] = useState('');
    const navigate = useNavigate();

    // Carregar todas as transações ao montar o componente
    useEffect(() => {
        axios.get('http://localhost:8084/transacoes')
            .then(response => {
                setTransacoes(response.data);
            })
            .catch(error => {
                console.error('Erro ao carregar transações:', error);
                setMensagem('Erro ao carregar as transações. Tente novamente.');
            });
    }, []);

    const calcularSaldo = () => {
        let saldo = 0;
        transacoes.forEach(transacao => {
            if (transacao.tipo === 'ENTRADA') {
                saldo += transacao.valor;
            } else if (transacao.tipo === 'SAÍDA') {
                saldo -= transacao.valor;
            }
        });
        return saldo;
    };

    return (
        <div className="caixa-page">
            <Navbar expand="lg" className="mb-5 bg-navbar">
                <Container>
                    <Navbar.Brand href="/produtos">
                        <img src="/logo.png" alt="Logo do Supermercado SPB" height={80} />
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="mx-auto">
                            <Nav.Link className="link-menu mx-4 fw-bold" href="/editar_usuario">Editar Usuário</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" href="/ver_carrinho">Ver Carrinho</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" href="#pedir-produto">Pedir Produto</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" href="/caixa">Caixa</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" onClick={() => navigate('/')}>Sair</Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            <Container>
                <h2 className="mb-5 text-center">Movimentações de Caixa</h2>
                {mensagem && <p className="text-center" style={{ color: 'red' }}>{mensagem}</p>}
                {transacoes.length > 0 ? (
                    <>
                        <Table striped bordered hover>
                            <thead>
                            <tr>
                                <th>Data/Hora</th>
                                <th>Tipo</th>
                                <th>Valor</th>
                            </tr>
                            </thead>
                            <tbody>
                            {transacoes.map(transacao => (
                                <tr key={transacao.id}>
                                    <td>{new Date(transacao.dataHora).toLocaleString()}</td>
                                    <td>{transacao.tipo}</td>
                                    <td>R${transacao.valor.toFixed(2)}</td>
                                </tr>
                            ))}
                            </tbody>
                        </Table>
                        <h3 className="text-center mt-4">Saldo Atual: R${calcularSaldo().toFixed(2)}</h3>
                    </>
                ) : (
                    <p className="text-center">Nenhuma movimentação registrada</p>
                )}
            </Container>
        </div>
    );
};

export default Caixa;

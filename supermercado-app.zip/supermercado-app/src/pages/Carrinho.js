import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Button, Table, Navbar, Nav } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const VerCarrinho = () => {
    const [carrinho, setCarrinho] = useState(null);
    const [mensagem, setMensagem] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
            const userParsed = JSON.parse(storedUser);
            axios.get(`http://localhost:8083/carrinhos/usuario/${userParsed.id}`)
                .then(response => {
                    setCarrinho(response.data);
                })
                .catch(error => {
                    console.error('Erro ao carregar carrinho:', error);
                    setMensagem('Erro ao carregar o carrinho. Tente novamente.');
                });
        }
    }, []);

    const finalizarCarrinho = () => {
        if (carrinho && carrinho.id) {
            // Fazer a requisição para finalizar o carrinho
            axios.put(`http://localhost:8083/carrinhos/${carrinho.id}/finalizar`)
                .then(response => {
                    setMensagem('Carrinho finalizado com sucesso!');

                    // Registrar a entrada no serviço de caixa
                    axios.post('http://localhost:8084/transacoes/entrada', {
                        valor: carrinho.valorTotal
                    })
                        .then(() => {
                            setMensagem('Carrinho finalizado e entrada registrada no caixa!');
                            // Limpa o carrinho do localStorage
                            localStorage.removeItem('carrinhoId');
                            setCarrinho(null);
                        })
                        .catch(error => {
                            console.error('Erro ao registrar entrada no caixa:', error);
                            setMensagem('Erro ao registrar entrada no caixa.');
                        });
                })
                .catch(error => {
                    console.error('Erro ao finalizar o carrinho:', error);
                    setMensagem('Erro ao finalizar o carrinho.');
                });
        }
    };

    return (
        <div className="ver-carrinho-page">
            <Navbar expand="lg" className="mb-5 bg-navbar">
                <Container>
                    <Navbar.Brand href="/produtos"> <img src="/logo.png" alt="Logo do Supermercado SPB" height={80} /></Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="mx-auto">
                            <Nav.Link className="link-menu mx-4 fw-bold" href="/editar_usuario">Editar Usuário</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" href="/ver_carrinho">Ver Carrinho</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" href="#pedir-produto">Pedir Produto</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" href="/caixa">Caixa</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" onClick={() => navigate('/')}>Sair</Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            <Container>
                <h2 className="mb-5 text-center">Meu Carrinho</h2>
                {mensagem && <p className="text-center" style={{ color: 'green' }}>{mensagem}</p>}
                {carrinho ? (
                    <>
                        <Table striped bordered hover>
                            <thead>
                            <tr>
                                <th>Produto</th>
                                <th>Quantidade</th>
                                <th>Preço</th>
                                <th>Total</th>
                            </tr>
                            </thead>
                            <tbody>
                            {carrinho.itens.map(item => (
                                <tr key={item.id}>
                                    <td>{item.nomeProduto}</td>
                                    <td>{item.quantidade}</td>
                                    <td>R${item.preco}</td>
                                    <td>R${(item.quantidade * item.preco).toFixed(2)}</td>
                                </tr>
                            ))}
                            </tbody>
                        </Table>
                        <h3 className="text-center">Valor Total: R${carrinho.valorTotal.toFixed(2)}</h3>
                        <Button variant="primary" className="w-100 mt-4" onClick={finalizarCarrinho}>
                            Finalizar Carrinho
                        </Button>
                    </>
                ) : (
                    <p className="text-center">Nenhum carrinho encontrado</p>
                )}
            </Container>
        </div>
    );
};

export default VerCarrinho;

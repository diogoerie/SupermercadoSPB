import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Registro = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        try {

            const response = await axios.post('http://localhost:8081/users/create', {
                nome: username,
                senha: password,
            });

            setSuccess('Usuário criado com sucesso! Você será redirecionado a pagina de login');
            setUsername('');
            setPassword('');
        } catch (error) {

            if (error.response && error.response.data) {
                setError(error.response.data);
            } else {
                setError('Erro ao criar o usuário. Tente novamente.');
            }
        }
    };

    useEffect(() => {
        if (success) {
            const timer = setTimeout(() => {
                navigate('/');
            }, 5000);

            return () => clearTimeout(timer);
        }
    }, [success, navigate]);

    return (
        <div className="login-page">
            <Container>
                <Row className="justify-content-md-center">
                    <Col md={4}>
                        <div className="login-form">
                            <div className="text-center mb-4">
                                <img
                                    src="/logo.png"
                                    alt="Logo do Supermercado SPB"
                                    className="mb-4"
                                />
                                <p>Informe os dados de usuario para que você possa acessar o sistema</p>
                            </div>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="formUsername" className="mb-3">
                                    <Form.Label>Nome:</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Digite seu nome"
                                        value={username}
                                        onChange={(e) => setUsername(e.target.value)}
                                        required
                                    />
                                </Form.Group>

                                <Form.Group controlId="formPassword" className="mb-3">
                                    <Form.Label>Senha:</Form.Label>
                                    <Form.Control
                                        type="password"
                                        placeholder="Digite sua senha"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        required
                                    />
                                </Form.Group>

                                {error && <p style={{ color: 'red' }}>{error}</p>}
                                {success && <p style={{ color: 'green' }}>{success}</p>}

                                <Button variant="primary" type="submit" className="w-100">
                                    Criar usuario
                                </Button>
                            </Form>
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
};

export default Registro;
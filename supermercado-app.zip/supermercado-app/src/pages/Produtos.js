import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Button, Form, Navbar, Nav } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Produtos = () => {
    const [produtos, setProdutos] = useState([]);
    const [quantidade, setQuantidade] = useState({});
    const [carrinhoId, setCarrinhoId] = useState(null);
    const [mensagem, setMensagem] = useState('');
    const [currentUser, setCurrentUser] = useState(null);
    const navigate = useNavigate();

    // Carregar o usuário do localStorage
    useEffect(() => {
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
            const userParsed = JSON.parse(storedUser);
            console.log('Usuário carregado do localStorage:', userParsed);
            setCurrentUser(userParsed);
        } else {
            console.log('Nenhum usuário encontrado no localStorage');
        }
    }, []);

    // Carregar os produtos e verificar/gerar carrinho assim que currentUser estiver definido
    useEffect(() => {
        if (currentUser) {
            // Carregar os produtos do backend
            axios.get('http://localhost:8082/produtos')
                .then(response => {
                    setProdutos(response.data);
                })
                .catch(error => {
                    console.error('Erro ao carregar produtos:', error);
                });

            // Verificar se o carrinho já existe no localStorage
            const storedCarrinhoId = localStorage.getItem('carrinhoId');
            if (storedCarrinhoId) {
                setCarrinhoId(storedCarrinhoId);
            } else {
                // Caso o carrinho ainda não exista, criar um novo
                axios.post(`http://localhost:8083/carrinhos/usuario/${currentUser.id}/novo`)
                    .then(response => {
                        setCarrinhoId(response.data.id);
                        localStorage.setItem('carrinhoId', response.data.id);
                    })
                    .catch(error => {
                        console.error('Erro ao criar carrinho:', error);
                    });
            }
        }
    }, [currentUser]); // Esse useEffect só roda quando currentUser é definido

    const handleQuantidadeChange = (produtoId, value) => {
        setQuantidade(prev => ({
            ...prev,
            [produtoId]: value
        }));
    };

    const adicionarAoCarrinho = (produtoId) => {
        const produto = produtos.find(p => p.id === produtoId); // Encontrar o produto pelo ID
        const qtd = quantidade[produtoId] || 1;

        if (carrinhoId && produto) {
            axios.post(`http://localhost:8083/carrinhos/${carrinhoId}/itens`, {
                produtoId,
                quantidade: qtd,
                preco: produto.preco // Usar o preço do produto encontrado
            })
                .then(response => {
                    setMensagem(`Produto ID ${produtoId} foi adicionado ao carrinho de ID ${carrinhoId}`);
                })
                .catch(error => {
                    console.error('Erro ao adicionar produto ao carrinho:', error);
                    setMensagem('Erro ao adicionar produto ao carrinho. Tente novamente.');
                });
        } else {
            setMensagem('Carrinho ou produto não encontrado. Tente novamente.');
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('user');
        localStorage.removeItem('carrinhoId');
        navigate('/');
    };

    return (
        <div className="produto-page">
            <Navbar expand="lg" className="mb-5 bg-navbar">
                <Container>
                    <Navbar.Brand href="/produtos"> <img src="/logo.png" alt="Logo do Supermercado SPB" height={80}/></Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="mx-auto">
                            <Nav.Link className="link-menu mx-4 fw-bold" href="/editar_usuario">Editar Usuário</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" href="/ver_carrinho">Ver Carrinho</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" href="#pedir-produto">Pedir Produto</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" href="/caixa">Caixa</Nav.Link>
                            <Nav.Link className="link-menu mx-4 fw-bold" onClick={handleLogout}>Sair</Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            <Container>
                <h2 className="mb-5 text-center">Lista de Produtos</h2>
                {mensagem && <p className="text-center" style={{ color: 'green' }}>{mensagem}</p>}  {/* Exibir mensagem */}
                <Row>
                    {produtos.map(produto => (
                        <Col md={4} key={produto.id} className="produto-item">
                            <div className="produto-card">
                                <h5>{produto.nome}</h5>
                                <p>Preço: R${produto.preco}</p>
                                <Form.Group controlId={`quantidade-${produto.id}`}>
                                    <Form.Label>Quantidade</Form.Label>
                                    <Form.Control
                                        type="number"
                                        value={quantidade[produto.id] || 1}
                                        min="1"
                                        onChange={(e) => handleQuantidadeChange(produto.id, e.target.value)}
                                    />
                                </Form.Group>
                                <Button
                                    variant="primary"
                                    onClick={() => adicionarAoCarrinho(produto.id)}
                                    className="mt-2"
                                >
                                    Adicionar ao Carrinho
                                </Button>
                            </div>
                        </Col>
                    ))}
                </Row>
            </Container>
        </div>
    );
};

export default Produtos;

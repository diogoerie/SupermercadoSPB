import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './pages/Login';
import Produtos from './pages/Produtos';
import NovoUsuario from './pages/novo_usuario';
import EditarUsuario from './pages/editar_usuario';
import VerCarrinho from './pages/Carrinho';
import Caixa from './pages/Caixa';
import './App.css';

function App() {
  return (
      <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/produtos" element={<Produtos />} />
            <Route path="/novo_usuario" element={<NovoUsuario />} />
            <Route path="/editar_usuario" element={<EditarUsuario />} />
            <Route path="/ver_carrinho" element={<VerCarrinho />} />
            <Route path="/caixa" element={<Caixa />} />
          {/* Aqui você adicionará as rotas para as outras páginas */}
        </Routes>
      </Router>
  );
}

export default App;
